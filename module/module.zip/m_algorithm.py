#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2019/1/11 上午10:55
# @Author  : Stardustsky
# @File    : m_algorithm.py
# @Software: PyCharm


def weight_func(vul_num_list, ml_score, libinjection_score, ratio):
    """
    加权模块，负责对处理结果进行加权
    :param vul_num_list:
    :param ml_score:
    :param libinjection_score:
    :param ratio:
    :return:
    """

    common_feature_num, attack_feature_num, all_feature_num = vul_num_list[0], vul_num_list[1], vul_num_list[2]
    ml_white_score, ml_black_score = ml_score[0], ml_score[1]
    # print common_feature_num, attack_feature_num, all_feature_num
    if all_feature_num <= 2:
        if attack_feature_num < 1:
            ml_black_score = (ml_black_score / 2)
            ml_white_score += 0.5
        else:
            ml_black_score = (ml_black_score / 1.8)
            ml_white_score += 0.4
        ml_black_score *= ratio

    if 2 < all_feature_num <= 4:
        if attack_feature_num < 1:
            ml_black_score = (ml_black_score / 1.8)
            ml_white_score += 0.3
        elif 1 <= attack_feature_num < 2:
            if attack_feature_num >= 5:
                attack_feature_num = 5
            ml_white_score /= 2
            ml_black_score += 0.2
            ml_black_score *= (1 + attack_feature_num * 0.04)
        else:
            if attack_feature_num >= 5:
                attack_feature_num = 5
            ml_white_score /= 2.5
            ml_black_score += 0.26
            ml_black_score *= (1 + attack_feature_num * 0.05)
        ml_black_score *= ratio

    if 5 <= all_feature_num:
        if attack_feature_num < 1:
            ml_white_score += 0.15
        elif 1 <= attack_feature_num < 2:
            if attack_feature_num >= 5:
                attack_feature_num = 5
            if common_feature_num > 0:
                ml_white_score /= 3
                ml_black_score += 0.28
                ml_black_score *= (1 + attack_feature_num * 0.05)
            else:
                ml_white_score /= 2
                ml_black_score += 0.25
        else:
            if attack_feature_num >= 5:
                attack_feature_num = 5
            if common_feature_num > 0:
                ml_white_score /= 3
                ml_black_score += 0.3
                ml_black_score *= (1 + attack_feature_num * 0.07)
            else:
                ml_white_score /= 2
                ml_black_score += 0.3
        ml_black_score *= ratio

    # print ml_black_score
    return [ml_white_score, ml_black_score]
