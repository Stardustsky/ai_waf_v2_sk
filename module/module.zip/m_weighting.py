#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/7 下午4:04
# @Author  : Stardustsky
# @File    : m_weighting.py
# @Software: PyCharm

from m_ml import attack_identify
from m_regex import attack_vec_load
from m_algorithm import weight_func
import time


def controller_center(para, attack_type, ratio, _multi_score, clf, regexes, vec, positon="url"):
    """
    :param para:
    :param attack_type:
    :param ratio:
    :param _multi_score:
    :param clf:
    :param regexes:
    :param vec:
    :param positon:
    :return:
    """
    # start = time.time()
    vul_num_list = attack_vec_load(para, attack_type, vec)
    # end = time.time()
    # print end - start
    ml_score = attack_identify(para, clf, regexes)
    libinjection_score = 0
    start = time.time()
    attack_score = weight_func(vul_num_list, ml_score, libinjection_score, ratio)
    # end = time.time()
    # print "加权耗时:%s" % (end - start)
    if attack_score[1] > attack_score[0]:
        _multi_score[attack_type] = [1, attack_score, ml_score, libinjection_score, vul_num_list]
    else:
        _multi_score[attack_type] = [0, attack_score, ml_score, libinjection_score, vul_num_list]
