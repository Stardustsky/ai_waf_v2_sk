#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2018/6/6 下午4:25
# @Author  : Stardustsky
# @File    : m_reg.py
# @Software: PyCharm


def attack_vec_load(url, attack_type, vec):
    """
    特征向量读取
    :param url:
    :param attack_type:
    :return:
    """

    common_vec, attack_vec = vec[0], vec[1][attack_type]
    common_vec_num = attack_vec_num = 0
    for i in common_vec:
        common_vec_num = common_vec_num + url.count(i)
    for i in attack_vec:
        attack_vec_num = attack_vec_num + url.count(i)

    return [common_vec_num, attack_vec_num, (common_vec_num + attack_vec_num)]
